from django.apps import AppConfig


class KsiStoreConfig(AppConfig):
    name = 'KSI_STORE'
